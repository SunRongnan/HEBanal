#' pair
#'
#' Homologous gene pair(Description)
#'
#' @examples
#'   head(pair)
"pair"

#' count
#'
#' Read count matrix(Description)
#'
#' @examples
#'   head(count)
"count"

#' group
#'
#' Grouping data of control group and stress group(Description)
#'
#' @examples
#'   head(group)
"group"
