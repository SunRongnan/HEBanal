#' Analysis and statistics of Homoeolog expression bias
#'
#' @param pair Homologous gene pair data.
#'     The data should be in data frame and
#'     the column names should be short for the respective subgenomes.
#' @param count The original count matrix obtained from transcriptome
#'     analysis must be in the form of a data frame
#' @param group The sample grouping file should be in the format of data frame,
#'     the first is listed as the control group,
#'     the second is listed as the stress group.
#'     It is important to note that the sample names for control
#'     and stress need to correspond to the sample names in count
#'
#' @return The results of HEB analysis, HEB cause analysis and
#'     differential expression identification will be output.
#'     All data results are saved in the current directory.
#' @export
#'
#' @examples HEB_res(pair, count, group)
HEB_res <- function(pair, count, group) {
  #-----0.File preprocessing----
  colnames(group) <- c("ck", "treat")
  colnames(count)[1] <- "id"

  sub1 <- merge(count, pair, by.x = "id", by.y = colnames(pair)[1])
  colnames(sub1)[2:(ncol(sub1) - 1)] <- paste0(colnames(pair)[1], "_", colnames(sub1)[2:(ncol(sub1) - 1)])

  sub2 <- merge(count, pair, by.x = "id", by.y = colnames(pair)[2])
  colnames(sub2)[2:(ncol(sub2) - 1)] <- paste0(colnames(pair)[2], "_", colnames(sub2)[2:(ncol(sub2) - 1)])

  sub <- merge(sub1, sub2, by.x = colnames(pair)[2], by.y = "id")
  count <- data.frame(id = paste(sub[, 2], sub[, 1], sep = "-"), sub[, c(-1, -2, -ncol(sub))])
  rownames(count) <- count[, 1]
  count <- count[-1]
  write.csv(count,"00.pair_count.csv",quote = F)

  sub1 <- paste0(colnames(pair)[1], "t")
  sub2 <- paste0(colnames(pair)[2], "t")
  cat("Data preprocessing was completed and HEB analysis was started.")
  cat("\n")

  #-----1.1-1.2.HEB analysis----
  ##----Define the HEB function----
  HEB_analy <- function(res,classification){
    condition <- factor(
      c(
        rep(colnames(pair)[1], n),
        rep(colnames(pair)[2], n)
      ),
      levels = c(colnames(pair)[1], colnames(pair)[2])
    )
    colData <- data.frame(row.names = colnames(res), condition)

    dds <- DESeqDataSetFromMatrix(
      countData = res,
      colData = colData,
      design = ~condition
    )
    dds <- DESeq(dds)
    res <- results(dds, contrast = c("condition", colnames(pair)[1], colnames(pair)[2]))
    res[which(res$log2FoldChange > 0 & res$padj <= 0.05), classification] <- paste(sub1, c("bias"))
    res[which(res$log2FoldChange < 0 & res$padj <= 0.05), classification] <- paste(sub2, c("bias"))
    res[which(res$padj > 0.05), classification] <- "No bias"
    res <- na.omit(res)
    res <- as.data.frame(res)
    res$id <- rownames(res)
    res <- res[c(ncol(res), ncol(res) - 1)]
  }
  ##-----Define data filtering functions----
  data_filter <- function(data){
    col_names <- colnames(data)
    combinations <- data.frame(combn(col_names, n))
    res <- c()
    for (i in 1:ncol(combinations)) {
      data_f <- data[, combinations[,i]]
      data_f <- data_f %>% filter_all(all_vars(. >= 10))
      id <- row.names(data_f)
      res <- c(res,id)
    }
    res <- data.frame(id=unique(res))
    res <- merge(data,res,by.x="row.names",by.y='id')
    row.names(res) <- res[,1]
    res[,1] <- NULL
    res
  }
  res_list <- list()
  single_num <- data.frame()
  HEB_num <- data.frame()
  for (i in 1:nrow(group)) {
    splitGroup <- group[i, ]
    ##----CK group----
    columns <- grep(splitGroup[1], names(count), value = TRUE)
    data <- count[, columns]
    n <- ncol(data) / 2
    ###-----data screening----
    res <- data_filter(data)
    ###---analysis----
    cat(paste(
      sub1, "has been extracted, with", n, "columns for", splitGroup[, 1], "and",
      sub2, "has been extracted, with", n, "columns for", splitGroup[, 1], ".\n"
    ))
    ck_res <- HEB_analy(res,splitGroup[, 1])
    cat("This group of HEB analyses has been completed.\n")
    ck_num <- as.data.frame(table(ck_res[2]))
    ck_num$Group <- splitGroup[, 1]
    colnames(ck_num)[1:2] <- c('Category','Count')
    print(ck_num)
    cat("\n")
    ##----treatment group----
    columns <- grep(splitGroup[2], names(count), value = TRUE)
    data <- count[, columns]
    n <- ncol(data) / 2
    ###-----data screening----
    res <- data_filter(data)
    ###---analysis----
    cat(paste(
      sub1, "has been extracted, with", n, "columns for", splitGroup[, 2], "and",
      sub2, "has been extracted, with", n, "columns for", splitGroup[, 2], ".\n"
    ))
    treat_res <- HEB_analy(res, splitGroup[, 2])
    cat("This group of HEB analyses has been completed.\n")
    treat_num <- as.data.frame(table(treat_res[2]))
    treat_num$Group <- splitGroup[, 2]
    colnames(treat_num)[1:2] <- c('Category','Count')
    print(treat_num)
    cat("\n")
    allres <- merge(ck_res, treat_res, by = "id")
    allres <- data.frame(id=allres[,1],m=paste0(allres[,2]," to ",allres[,3]))
    colnames(allres)[2] <- splitGroup[, 2]

    num <- as.data.frame(table(allres[2]))
    num$Group <- splitGroup[, 2]
    colnames(num)[1:2] <- c('Category','Count')
    print(num)
    cat("\n")
    allnum <- rbind(ck_num,treat_num)
    single_num <- rbind(single_num,allnum)
    HEB_num <- rbind(HEB_num,num)
    res_list[[i]] <- allres
  }
  HEB_result <- Reduce(function(x, y) merge(x, y, by = "id", all = TRUE), res_list)
  write.csv(HEB_result, "1.1.HEB_megre_result.csv", row.names = F, quote = F)

  single_num <- unique(single_num)
  write.csv(single_num, "1.2.HEB_split_num.csv", row.names = F, quote = F)

  HEB_num_w <- pivot_wider(HEB_num, names_from = "Category", values_from = "Count")
  HEB_num <- pivot_longer(HEB_num_w, cols = -c('Group'),names_to = 'Category', values_to= 'Count')
  write.csv(HEB_num, "1.2.HEB_merge_num.csv", row.names = F, quote = F)
  cat("The HEB analysis is complete.\n")

  #-----1.3.HEB transition visualization----
  HEB_num$Group <- gsub("_", " ", HEB_num$Group)
  HEB_num$Group <- gsub("\\.", "-", HEB_num$Group)
  HEB_Sankey <- function(num, key) {
    result_plot <- num[num$Group == key, ]
    result_plot$Category <- gsub(" to ", "--", result_plot$Category)
    split <- separate(result_plot[2], col = Category, into = c("Ck", "Treatment"), sep = "--")
    class <- split$Ck
    result_plot <- cbind(split, Count = result_plot$Count, class)
    result_plot <- result_plot %>%
      arrange(factor(class, levels = c(paste0(sub1," bias"),"No bias",paste0(sub2," bias"))))
    result_plot$class <- factor(result_plot$class,
                                levels = c(paste0(sub1," bias"),"No bias",paste0(sub2," bias")))
    result_plot$Ck <- factor(result_plot$Ck,
                             levels = c(paste0(sub1," bias"),"No bias",paste0(sub2," bias")))
    result_plot$Treatment <- factor(result_plot$Treatment,
                                    levels = c(paste0(sub1," bias"),"No bias",paste0(sub2," bias")))
    ggplot(result_plot, aes(y = Count, axis1 = Ck, axis2 = Treatment)) +
      geom_flow() +
      geom_alluvium(aes(fill = class)) +
      guides(fill = "none") +
      geom_stratum(alpha = 0.01) +
      scale_fill_manual(values = c("#FBC03E", "#91BEE1", "#C95140")) +
      geom_text(stat = "stratum", size = 12, aes(label = after_stat(stratum), family="serif")) +
      theme_void() +
      ggtitle(key) +
      theme(plot.title = element_text(hjust = 0.5, vjust = -1),
            title = element_text(size = 40, family="serif"))
  }
  plot_list <- list()
  for (key in unique(HEB_num$Group)) {
    plot <- HEB_Sankey(HEB_num, key)
    plot_list[[length(plot_list) + 1]] <- plot
  }

  row <- if (is.integer(length(plot_list) / 4)) {
    length(plot_list) / 4
  } else {
    floor(length(plot_list) / 4) + 1
  }
  Sankey <- plot_grid(plotlist = plot_list, nrow = row)
  print(Sankey)
  ggsave("1.3.HEB_transition.pdf",height = 10,width = 27,dpi = 300)

  #----1.3.HEB number visualization----
  single_num$Group <- gsub("_", " ", single_num$Group)
  single_num$Group <- gsub("\\.", "-", single_num$Group)
  single_num$Group <- factor(single_num$Group,levels = unique(single_num$Group))
  bar <- ggplot(single_num, aes(Group, y = Count, fill = Category))+
    geom_bar(stat = 'identity',width = 0.5)+
    scale_fill_manual(values=c("#F6D8C0", "#F7B7B5", "#ADCED7"))+
    theme_minimal()+
    theme(axis.text.x = element_text(angle = 45, hjust = 1,size = 15, family="serif"),
          axis.text.y = element_text(size = 15, family="serif" ),
          axis.title = element_text(size = 20, family="serif"),
          legend.text = element_text(size = 19, family="serif"),
          legend.title = element_text(size = 20, family="serif"),
          title = element_text(size = 20,family="serif"),
          axis.title.x = element_blank(),
          plot.title = element_text(hjust = 0.5, vjust = -1,family="serif"))+

    labs(y = "Number")
  print(bar)
  ggsave("1.3.HEB_number.pdf",height = 5,width = 5,dpi = 300)
  cat("\n")
  cat("Visualization of HEB analysis results has been completed.\n")
  cat("\n")

  #----2.1-2.2.HEB DESeq----
  HEB_DEseq <- function(data,sub){
    class <- paste0(substr(colnames(data)[1], 1, 2), splitGroup[2])
    colData <- data.frame(row.names = colnames(data), condition)
    dds <- DESeqDataSetFromMatrix(countData = data, colData = colData, design = ~condition)
    dds <- DESeq(dds)
    res <- results(dds, contrast = c("condition", "Treat", "CK"))
    res[which(res$log2FoldChange > 1 & res$padj <= 0.05), class] <- paste(sub, c("up regulated"))
    res[which(res$log2FoldChange < -1 & res$padj <= 0.05), class] <- paste(sub, c("down regulated"))
    res[which(res$padj > 0.05), class] <- "No change"
    res <- na.omit(res)
    res <- as.data.frame(res)
    res$id <- rownames(res)
    res <- res[c(ncol(res), ncol(res) - 1)]
  }
  cat("Differential gene expression analysis was initiated.\n")
  res_list <- list()
  single_num <- data.frame()
  DEseq_num <- data.frame()
  for (i in 1:nrow(group)) {
    splitGroup <- group[i, ]

    ck_columns <- grep(splitGroup[1], names(count), value = TRUE)
    ck_data <- count[, ck_columns]
    sub1_ck <- ck_data[, 1:(ncol(ck_data) / 2)]
    sub2_ck <- ck_data[, ((ncol(ck_data) / 2) + 1):(ncol(ck_data))]

    treat_columns <- grep(splitGroup[2], names(count), value = TRUE)
    treat_data <- count[, treat_columns]
    sub1_treat <- treat_data[1:(ncol(treat_data) / 2)]
    sub2_treat <- treat_data[((ncol(treat_data) / 2) + 1):(ncol(treat_data))]

    sub1_data <- merge(sub1_ck, sub1_treat, by = "row.names")
    rownames(sub1_data) <- sub1_data$Row.names
    sub1_data$Row.names <- NULL
    sub2_data <- merge(sub2_ck, sub2_treat, by = "row.names")
    rownames(sub2_data) <- sub2_data$Row.names
    sub2_data$Row.names <- NULL

    n <- min(ncol(ck_data) / 2,ncol(treat_data) / 2)

    cat(paste(
      sub1, "has been extracted, with", ncol(sub1_ck), "columns for", splitGroup[1], "and",
      ncol(sub1_treat), "columns for", splitGroup[2], ".\n"
    ))
    sub1_data <- data_filter(sub1_data)
    condition <- factor(c(rep("CK", ncol(sub1_ck)), rep("Treat", ncol(sub1_treat))), levels = c("CK", "Treat"))
    sub1_res <- HEB_DEseq(sub1_data,colnames(pair)[1])
    cat("This group of HEB difference analysis has been completed.\n")
    cat("\n")
    sub1_num <- as.data.frame(table(sub1_res[2]))
    sub1_num$Group <- colnames(sub1_res)[2]
    colnames(sub1_num)[1:2] <- c('Category','Count')
    print(sub1_num)
    cat("\n")

    cat(paste(
      sub2, "has been extracted, with", ncol(sub2_ck), "columns for", splitGroup[1], "and",
      ncol(sub2_treat), "columns for", splitGroup[2], ".\n"
    ))
    sub2_data <- data_filter(sub2_data)
    condition <- factor(c(rep("CK", ncol(sub2_ck)), rep("Treat", ncol(sub2_treat))), levels = c("CK", "Treat"))
    sub2_res <- HEB_DEseq(sub2_data,colnames(pair)[2])
    cat("This group of HEB difference analysis has been completed.\n")
    cat("\n")
    sub2_num <- as.data.frame(table(sub2_res[2]))
    sub2_num$Group <- colnames(sub2_res)[2]
    colnames(sub2_num)[1:2] <- c('Category','Count')
    print(sub2_num)
    cat("\n")

    allres <- merge(sub1_res, sub2_res, by = "id")
    allres <- data.frame(id=allres[,1],m=paste0(allres[,2],"--",allres[,3]))
    colnames(allres)[2] <- splitGroup[, 2]
    num <- as.data.frame(table(allres[2]))
    num$Group <- splitGroup[, 2]
    colnames(num)[1:2] <- c('Category','Count')
    print(num)
    cat("\n")

    allnum <- rbind(sub1_num,sub2_num)
    single_num <- rbind(single_num,allnum)
    DEseq_num <- rbind(DEseq_num,num)
    res_list[[i]] <- allres

  }
  Deseq_result <- Reduce(function(x, y) merge(x, y, by = "id", all = TRUE), res_list)
  for (col in colnames(Deseq_result)) {
    Deseq_result[[col]] <- sub("No change--No change", "Both homoeologs no change", Deseq_result[[col]])
    Deseq_result[[col]] <- sub(paste0(colnames(pair)[1],
                                      " down regulated--",
                                      colnames(pair)[2],
                                      " down regulated"),
                               "Both homoeologs down-regulated", Deseq_result[[col]])
    Deseq_result[[col]] <- sub(paste0(colnames(pair)[1],
                                      " up regulated--",
                                      colnames(pair)[2],
                                      " up regulated"),
                               "Both homoeologs up-regulated",Deseq_result[[col]])
    Deseq_result[[col]] <- sub(paste0("No change",
                                      "--",
                                      colnames(pair)[2],
                                      " up regulated"),
                               paste0("No change and ",colnames(pair)[2]," up-regulated"),
                               Deseq_result[[col]])
    Deseq_result[[col]] <- sub(paste0("No change",
                                      "--",
                                      colnames(pair)[2],
                                      " down regulated"),
                               paste0("No change and ",colnames(pair)[2]," down-regulated"), Deseq_result[[col]])
    Deseq_result[[col]] <- sub(paste0(colnames(pair)[1],
                                      " up regulated--No change"),
                               "A up-regulated and no change", Deseq_result[[col]])
    Deseq_result[[col]] <- sub(paste0(colnames(pair)[1],
                                      " down regulated--No change"),
                               "A down-regulated and no change", Deseq_result[[col]])
    Deseq_result[[col]] <- sub(paste0(colnames(pair)[1],
                                      " down regulated--",
                                      colnames(pair)[2],
                                      " up regulated"),
                               paste0("A down and ",colnames(pair)[2]," up-regulated"), Deseq_result[[col]])
    Deseq_result[[col]] <- sub(paste0(colnames(pair)[1],
                                      " up regulated--",
                                      colnames(pair)[2],
                                      " down regulated"),
                               paste0("A up and ",colnames(pair)[2]," down-regulated"), Deseq_result[[col]])

  }
  write.csv(Deseq_result, "2.1.Deseq_megre_result.csv", row.names = F, quote = F)
  write.csv(single_num, "2.2.Deseq_split_num.csv", row.names = F, quote = F)
  DEseq_num_w <- pivot_wider(DEseq_num, names_from = "Category", values_from = "Count")
  DEseq_num <- pivot_longer(DEseq_num_w, cols = -c('Group'),names_to = 'Category', values_to= 'Count')
  DEseq_num$Category <- sub("No change--No change", "Both homoeologs no change", DEseq_num$Category)
  DEseq_num$Category <- sub(paste0(colnames(pair)[1],
                                   " down regulated--",
                                   colnames(pair)[2],
                                   " down regulated"),
                            "Both homoeologs down-regulated", DEseq_num$Category)
  DEseq_num$Category <- sub(paste0(colnames(pair)[1],
                                   " up regulated--",
                                   colnames(pair)[2],
                                   " up regulated"),
                            "Both homoeologs up-regulated",DEseq_num$Category)
  DEseq_num$Category <- sub(paste0("No change",
                                   "--",
                                   colnames(pair)[2],
                                   " up regulated"),
                            paste0("No change and ",colnames(pair)[2]," up-regulated"), DEseq_num$Category)
  DEseq_num$Category <- sub(paste0("No change",
                                   "--",
                                   colnames(pair)[2],
                                   " down regulated"),
                            paste0("No change and ",colnames(pair)[2]," down-regulated"), DEseq_num$Category)
  DEseq_num$Category <- sub(paste0(colnames(pair)[1],
                                   " up regulated--No change"),
                            "A up-regulated and no change", DEseq_num$Category)
  DEseq_num$Category <- sub(paste0(colnames(pair)[1],
                                   " down regulated--No change"),
                            "A down-regulated and no change", DEseq_num$Category)
  DEseq_num$Category <- sub(paste0(colnames(pair)[1],
                                   " down regulated--",
                                   colnames(pair)[2],
                                   " up regulated"),
                            paste0("A down and ",colnames(pair)[2]," up-regulated"), DEseq_num$Category)
  DEseq_num$Category <- sub(paste0(colnames(pair)[1],
                                   " up regulated--",
                                   colnames(pair)[2],
                                   " down regulated"),
                            paste0("A up and ",colnames(pair)[2]," down-regulated"), DEseq_num$Category)
  DEseq_num$Group <- gsub("_", " ", DEseq_num$Group)
  DEseq_num$Group <- gsub("\\.", "-", DEseq_num$Group)
  write.csv(DEseq_num, "2.2.DEseq_merge_num.csv", row.names = F, quote = F)
  cat("Differential gene expression analysis has been completed.\n")

  #----3.1.HEB cause----
  res_list <- list()
  for (i in 1:nrow(group)) {
    splitGroup <- group[i, 2]
    res_data <- data.frame(id = HEB_result$id, col_value = HEB_result[, splitGroup])
    rea_data <- data.frame(id = Deseq_result$id, col_value = Deseq_result[, splitGroup])
    m <- full_join(res_data, rea_data, by = "id")
    m <- na.omit(m)
    m <- as.data.frame(table(m[, 3], m[, 2]))
    m <- pivot_wider(m, names_from = "Var2", values_from = "Freq")
    m <- data.frame(Group = splitGroup, m)
    res_list[[i]] <- m
  }
  cause_result <- bind_rows(res_list)
  colnames(cause_result) <- gsub("\\.\\.", " to ", colnames(cause_result))
  colnames(cause_result) <- gsub("\\.", " ", colnames(cause_result))
  colnames(cause_result)[2] <- "Type"
  cause_result$Type <- sub("No change--No change", "Both homoeologs no change", cause_result$Type)
  cause_result$Type <- sub(paste0(colnames(pair)[1],
                                  " down regulated--",
                                  colnames(pair)[2],
                                  " down regulated"),
                           "Both homoeologs down-regulated", cause_result$Type)
  cause_result$Type <- sub(paste0(colnames(pair)[1],
                                  " up regulated--",
                                  colnames(pair)[2],
                                  " up regulated"),
                           "Both homoeologs up-regulated",cause_result$Type)
  cause_result$Type <- sub(paste0("No change",
                                  "--",
                                  colnames(pair)[2],
                                  " up regulated"),
                           paste0("No change and ",colnames(pair)[2]," up-regulated"), cause_result$Type)
  cause_result$Type <- sub(paste0("No change",
                                  "--",
                                  colnames(pair)[2],
                                  " down regulated"),
                           paste0("No change and ",colnames(pair)[2]," down-regulated"), cause_result$Type)
  cause_result$Type <- sub(paste0(colnames(pair)[1],
                                  " up regulated--No change"),
                           "A up-regulated and no change", cause_result$Type)
  cause_result$Type <- sub(paste0(colnames(pair)[1],
                                  " down regulated--No change"),
                           "A down-regulated and no change", cause_result$Type)
  cause_result$Type <- sub(paste0(colnames(pair)[1],
                                  " down regulated--",
                                  colnames(pair)[2],
                                  " up regulated"),
                           paste0("A down and ",colnames(pair)[2]," up-regulated"), cause_result$Type)
  cause_result$Type <- sub(paste0(colnames(pair)[1],
                                  " up regulated--",
                                  colnames(pair)[2],
                                  " down regulated"),
                           paste0("A up and ",colnames(pair)[2]," down-regulated"), cause_result$Type)
  write.csv(cause_result, "3.1.HEB_cause_num.csv", row.names = F, quote = F)

  res_list <- list()
  for (i in 1:nrow(group)) {
    splitGroup <- group[i, ][, 2]
    subset_data <- cause_result[cause_result[, 1] == splitGroup, ]
    result <- data.frame(matrix(
      ncol = (ncol(cause_result) - 2),
      nrow = nrow(subset_data)
    ))
    for (k in 1:nrow(subset_data)) {
      for (j in 3:ncol(subset_data)) {
        value <- round(subset_data[k, j] / sum(subset_data[, j], na.rm = TRUE) * 100, 2)
        result[k, (j - 2)] <- value
      }
    }
    res <- cbind(data.frame(splitGroup, subset_data[, 2]), result)
    colnames(res) <- colnames(cause_result)
    res_list[[i]] <- res
  }
  final_result <- do.call(rbind, res_list)
  colnames(final_result) <- gsub("\\.\\.", " to ", colnames(final_result))
  colnames(final_result) <- gsub("\\.", " ", colnames(final_result))
  final_result$Group <- gsub("_", " ", final_result$Group)
  final_result$Group <- gsub("\\.", "-", final_result$Group)
  final_result$Type <- sub("No change--No change", "Both homoeologs no change", final_result$Type)
  final_result$Type <- sub(paste0(colnames(pair)[1],
                                  " down regulated--",
                                  colnames(pair)[2],
                                  " down regulated"),
                           "Both homoeologs down-regulated", final_result$Type)
  final_result$Type <- sub(paste0(colnames(pair)[1],
                                  " up regulated--",
                                  colnames(pair)[2],
                                  " up regulated"),
                           "Both homoeologs up-regulated", final_result$Type)
  final_result$Type <- sub(paste0("No change",
                                  "--",
                                  colnames(pair)[2],
                                  " up regulated"),
                           paste0("No change and ",colnames(pair)[2]," up-regulated"), final_result$Type)
  final_result$Type <- sub(paste0("No change",
                                  "--",
                                  colnames(pair)[2],
                                  " down regulated"),
                           paste0("No change and ",colnames(pair)[2]," down-regulated"), final_result$Type)
  final_result$Type <- sub(paste0(colnames(pair)[1],
                                  " up regulated--No change"),
                           "A up-regulated and no change", final_result$Type)
  final_result$Type <- sub(paste0(colnames(pair)[1],
                                  " down regulated--No change"),
                           "A down-regulated and no change", final_result$Type)
  final_result$Type <- sub(paste0(colnames(pair)[1],
                                  " down regulated--",
                                  colnames(pair)[2],
                                  " up regulated"),
                           paste0("A down and ",colnames(pair)[2]," up-regulated"), final_result$Type)
  final_result$Type <- sub(paste0(colnames(pair)[1],
                                  " up regulated--",
                                  colnames(pair)[2],
                                  " down regulated"),
                           paste0("A up and ",colnames(pair)[2]," down-regulated"), final_result$Type)
  write.csv(final_result, "3.1.HEB_cause_num_Ratio.csv", row.names = F, quote = F)

  #-----3.2.HEB cause visualization----

  cat("\n")
  pdf_list <- list()
  for (keys in unique(final_result$Group)) {
    result_plot <- final_result[final_result$Group == keys, ]
    result_plot <- result_plot[, colSums(is.na(result_plot)) == 0]
    df <- pivot_longer(result_plot, cols = -c('Group', 'Type'), names_to = 'Class', values_to = 'Value')

    df$Type <- factor(df$Type, levels = rev(unique(df$Type)))
    cause_plot <- ggplot(df, aes(x = 3, y = Value, fill = Type)) +
      geom_col(width = 1.5, color = 'white') +
      facet_wrap(~Group + Class, ncol = 3, nrow = 3) +
      coord_polar(theta = "y") +
      xlim(c(0.2, 3.8)) +
      theme_bw() +
      theme(
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        panel.grid = element_blank(),
        legend.text = element_text(size = 19, family="serif"),
        legend.title = element_text(size = 20, family="serif"),
        axis.title = element_text(size = 20, family="serif"),
        strip.text = element_text(size = 19, family = "serif")
      ) +
      labs(fill = "Type") +
      xlab("") + ylab("") + scale_fill_npg(alpha = 0.6)

    print(keys)
    pdf_file <- paste0(keys, ".pdf")
    ggsave(pdf_file, cause_plot, width = 14, height = 10)

    pdf_list[[length(pdf_list) + 1]] <- pdf_file
  }
  output_file <- "3.2.merge_HEB_cause.pdf"
  pdf_combine(pdf_list, output_file)
  cat("The visualization of HEB cause analysis is over.")
  cat("\n")
  #----2.1-2.2.HEB DESeq Sum----
  HEB_DEseq_sum <- function(data){
    condition <- factor(c(rep("CK", ncol(ck_sum)), rep("Treat", ncol(treat_sum))), levels = c("CK", "Treat"))
    colData <- data.frame(row.names = colnames(data), condition)
    dds <- DESeqDataSetFromMatrix(countData = data, colData = colData, design = ~condition)
    dds <- DESeq(dds)
    res <- results(dds, contrast = c("condition", "Treat", "CK"))
    res[which(res$log2FoldChange > 1 & res$padj <= 0.05), splitGroup[, 2]] <- "up regulated"
    res[which(res$log2FoldChange < -1 & res$padj <= 0.05), splitGroup[, 2]] <- "down regulated"
    res[which(res$padj > 0.05), splitGroup[, 2]] <- "No change"
    res <- na.omit(res)
    res <- as.data.frame(res)
    res$id <- rownames(res)
    res <- res[c(ncol(res), ncol(res) - 1)]
  }
  cat("Differential expression analysis after subgenomic addition is ongoing.\n")
  cat("\n")
  res_list <- list()
  allnum <- data.frame()
  for (i in 1:nrow(group)) {
    splitGroup <- group[i, ]
    ck_columns <- grep(splitGroup[1], names(count), value = TRUE)
    ck_data <- count[, ck_columns]

    A <- ck_data[, 1:(ncol(ck_data) / 2)]
    B <- ck_data[, ((ncol(ck_data) / 2) + 1):(ncol(ck_data))]

    ck_sum <- data.frame(matrix(nrow = nrow(A), ncol = ncol(A)))
    for (j in 1:ncol(A)) {
      ck_sum[, j] <- A[, j] + B[, j]
    }
    colnames(ck_sum) <- substr(colnames(A), 3, nchar(colnames(A)))

    treat_columns <- grep(splitGroup[2], names(count), value = TRUE)
    treat_data <- count[, treat_columns]

    A <- treat_data[, 1:(ncol(treat_data) / 2)]
    B <- treat_data[, ((ncol(treat_data) / 2) + 1):(ncol(treat_data))]

    treat_sum <- data.frame(matrix(nrow = nrow(A), ncol = ncol(A)))
    for (k in 1:ncol(A)) {
      treat_sum[, k] <- A[, k] + B[, k]
    }
    colnames(treat_sum) <- substr(colnames(A), 3, nchar(colnames(A)))

    res <- data.frame(row.names = rownames(count), ck_sum, treat_sum)
    n <- min(ncol(ck_sum),ncol(treat_sum))
    res <- data_filter(res)
    cat("\n")
    cat(paste0(
      "Target data has been extracted, with ",
      ncol(ck_sum), " columns for ", splitGroup[1], " and ",
      ncol(treat_sum), " columns for ", splitGroup[2], ".\n"
    ))
    result <- HEB_DEseq_sum(res)
    num <- as.data.frame(table(result[2]))
    num$Group <- splitGroup[, 2]
    colnames(num)[1:2] <- c('Category','Count')
    print(num)
    cat("\n")
    allnum <- rbind(allnum,num)
    res_list[[i]] <- result
  }

  Deseq_result_sum <- Reduce(function(x, y) merge(x, y, by = "id", all = TRUE), res_list)
  write.csv(Deseq_result_sum, "2.1.Deseq_Sum_result.csv", row.names = F, quote = F)
  DEseq_Sum_num_w <- pivot_wider(allnum, names_from = "Category", values_from = "Count")
  DEseq_Sum_num <- pivot_longer(DEseq_Sum_num_w, cols = -c('Group'),names_to = 'Category', values_to= 'Count')
  write.csv(DEseq_Sum_num, "2.2.Deseq_Sum_num.csv", row.names = F, quote = F)
  cat("Differential expression analysis after subgenomic addition has been completed.\n")

  #----3.1.HEB cause Sum----
  res_list <- list()
  for (i in 1:nrow(group)) {
    splitGroup <- group[i, 2]
    res_data <- data.frame(id = HEB_result$id, col_value = HEB_result[, splitGroup])
    rea_data <- data.frame(id = Deseq_result_sum$id, col_value = Deseq_result_sum[, splitGroup])
    m <- full_join(res_data, rea_data, by = "id")
    m <- na.omit(m)
    m <- as.data.frame(table(m[, 3], m[, 2]))
    m <- pivot_wider(m, names_from = "Var2", values_from = "Freq")
    m <- data.frame(Group = splitGroup, m)
    res_list[[i]] <- m
  }
  final_result_sum <- bind_rows(res_list)
  colnames(final_result_sum) <- gsub("\\.\\.", " to ", colnames(final_result_sum))
  colnames(final_result_sum) <- gsub("\\.", " ", colnames(final_result_sum))
  colnames(final_result_sum)[2] <- "Type"
  write.csv(final_result_sum, "3.1.HEB_cause_Sum_num.csv", row.names = F, quote = F)

  res_list <- list()
  for (i in 1:nrow(group)) {
    splitGroup <- group[i, ][, 2]
    subset_data <- final_result_sum[final_result_sum[, 1] == splitGroup, ]
    result <- data.frame(matrix(
      ncol = (ncol(final_result_sum) - 2),
      nrow = nrow(subset_data)
    ))
    for (k in 1:nrow(subset_data)) {
      for (j in 3:ncol(subset_data)) {
        value <- round(subset_data[k, j] / sum(subset_data[, j], na.rm = TRUE) * 100, 2)
        result[k, (j - 2)] <- value
      }
    }
    res <- cbind(data.frame(splitGroup, subset_data[, 2]), result)
    colnames(res) <- colnames(final_result_sum)
    res_list[[i]] <- res
  }
  final_result_sum_ratio <- do.call(rbind, res_list)
  colnames(final_result_sum_ratio) <- gsub("\\.\\.", " to ", colnames(final_result_sum_ratio))
  colnames(final_result_sum_ratio) <- gsub("\\.", " ", colnames(final_result_sum_ratio))
  final_result_sum_ratio$Group <- gsub("_", " ", final_result_sum_ratio$Group)
  final_result_sum_ratio$Group <- gsub("\\.", "-", final_result_sum_ratio$Group)
  final_result_sum_ratio$Type <- gsub("down regulated",
                                      "down-regulated", final_result_sum_ratio$Type)
  final_result_sum_ratio$Type <- gsub("up regulated",
                                      "up-regulated", final_result_sum_ratio$Type)
  write.csv(final_result_sum_ratio, "3.1.HEB_cause_Sum_num_Ratio.csv", row.names = F, quote = F)

  #-----3.2.HEB cause Sum visualization----

  pdf_list <- list()
  for (key2 in unique(final_result_sum_ratio$Group)) {
    result_plot <- final_result_sum_ratio[final_result_sum_ratio$Group == key2, ]
    result_plot <- result_plot[, colSums(is.na(result_plot)) == 0]
    df <- tidyr::pivot_longer(result_plot, cols = -c('Group', 'Type'), names_to = 'Class', values_to = 'Value')
    df$Type <- factor(df$Type, levels = c("No change","up-regulated","down-regulated" ))
    cause_plot <- ggplot(df, aes(x = 3, y = Value, fill = Type)) +
      geom_col(width = 1.5, color = 'white') +
      facet_wrap(~Group + Class, ncol = 3, nrow = 3) +
      coord_polar(theta = "y") +
      xlim(c(0.2, 3.8)) +
      theme_bw() +
      theme(
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        panel.grid = element_blank(),
        legend.text = element_text(size = 19, family="serif"),
        legend.title = element_text(size = 20, family="serif"),
        axis.title = element_text(size = 20, family="serif"),
        strip.text = element_text(size = 19, family = "serif")
      ) +
      labs(fill = "Type") +
      xlab("") + ylab("") + scale_fill_locuszoom(alpha = 0.6)

    print(key2)
    pdf_file <- paste0(key2, "_Sum.pdf")
    ggsave(pdf_file, cause_plot, width = 14, height = 10)

    pdf_list[[length(pdf_list) + 1]] <- pdf_file
  }
  output_file <- "3.2.merge_HEB_cause_Sum.pdf"
  pdf_combine(pdf_list, output_file)
  cat("The visualization of differential expression analysis after subgenomic addition has been completed.\n")
  cat("\nAll analyses have been completed, please view the result file in the current directory and the visual results in the plot interface.\n")
}












